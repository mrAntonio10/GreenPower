package com.upb.upb.service;

import java.util.List;

public interface ArduinoService {
    List<ArduinoService> findAll();
}
