package com.upb.upb.model.dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ArduinoDto {
    private String sensor;
    private Double temperatura;
}
